/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Copyright 2023-2024 NXP
 */
#ifndef IPC_XEN_H
#define IPC_XEN_H

#endif /* IPC_XEN_H */
