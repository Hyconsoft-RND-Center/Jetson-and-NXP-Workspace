#include <errno.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <semaphore.h>
#include <signal.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <pthread.h>
 
#include "ipc-shm.h"
#include "ipcf_Ip_Cfg.h"
 
#include <rcl/rcl.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>
#include <autoware_auto_control_msgs/msg/ackermann_control_command.h>
#include <rosidl_runtime_c/message_type_support_struct.h>
#include <rmw/types.h>
 
#define IPC_SHM_DEV_MEM_NAME "/dev/mem"
 
#define CTRL_CHAN_ID 0
#define CTRL_CHAN_SIZE 64
#define MAX_SAMPLE_MSG_LEN 64
#define L_BUF_LEN 4096
#define IPC_SHM_SIZE 0x100000
 
#define UDP_PORT 5000
#define UDP_ADDRESS "192.168.0.15"
static int udp_socket;
static struct sockaddr_in udp_addr;
 
/* convenience wrappers for printing messages */
#define pr_fmt(fmt) "Autoware-Subscriber: %s(): " fmt
#define info_fmt(fmt) "Autoware-Subscriber: " fmt
#define sample_err(fmt, ...) printf(pr_fmt(fmt), __func__, ##__VA_ARGS__)
#define sample_info(fmt, ...) printf(info_fmt(fmt), ##__VA_ARGS__)
#ifdef DEBUG
#define sample_dbg(fmt, ...) printf(pr_fmt(fmt), __func__, ##__VA_ARGS__)
#else
#define sample_dbg(fmt, ...)
#endif
 
#ifndef ARRAY_SIZE
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))
#endif
 
#ifndef IPC_MEMCPY_BYTES_ALIGNED
#define IPC_MEMCPY_BYTES_ALIGNED 8
#endif
 
#define IS_ALIGNED(x, a) (((x) & ((typeof(x))(a) - 1)) == 0)
 
// static int msg_sizes[IPC_SHM_MAX_POOLS] = {MAX_SAMPLE_MSG_LEN};
// static int msg_sizes_count = 1;
 
/**
* struct ipc_sample_app - sample app private data
* @num_channels:   number of channels configured in this sample
* @num_msgs:       number of messages to be sent to remote app
* @ctrl_shm:       control channel local shared memory
* @last_rx_no_msg: last number of received message
* @last_tx_msg:    last transmitted message
* @last_rx_msg:    last received message
* @local_virt_shm: local shared memory virtual address
* @mem_fd:     MEM device file descriptor
* @local_shm_offset:   local ShM offset in mapped page
* @local_shm_map:  local ShM mapped page address
* @sema:       binary semaphore for sync send_msg func with shm_rx_cb
* @instance:       instance id
*/
static struct ipc_sample_app
{
    int num_channels;
    int num_msgs;
    char *ctrl_shm;
    volatile int last_rx_no_msg;
    char last_tx_msg[L_BUF_LEN];
    char last_rx_msg[L_BUF_LEN];
    int *local_virt_shm;
    int mem_fd;
    size_t local_shm_offset;
    int *local_shm_map;
    sem_t sema;
    uint8_t instance;
    pthread_mutex_t lock; // Add mutex for thread safety
} app;
 
/* Add global stop flag for signal handling */
volatile sig_atomic_t stop_requested = 0;
 
/* link with generated variables */
const void *rx_cb_arg = &app;
 
/* Init IPC shared memory driver (see ipc-shm.h for API) */
static int init_ipc_shm(void)
{
    int err;
    do
    {
        err = ipc_shm_init(&ipcf_shm_instances_cfg);
    } while (err == -EAGAIN);
    if (err)
        return err;
 
    app.num_channels = ipcf_shm_instances_cfg.shm_cfg[0].num_channels;
 
    /* acquire control channel memory once */
    app.ctrl_shm = ipc_shm_unmanaged_acquire(app.instance, CTRL_CHAN_ID);
    if (!app.ctrl_shm)
    {
        sample_err("failed to get memory of control channel");
        return -ENOMEM;
    }
 
    return 0;
}
 
/*
* ipc implementation of memcpy to IO memory space
*/
void ipc_memcpy_toio(void *dst, void *buf, size_t count)
{
    printf("\n");
    static int bytes_aligned = IPC_MEMCPY_BYTES_ALIGNED;
    char *dst_casted = (char *)dst;
    char *buf_casted = (char *)buf;
 
    // Copy bytes until both pointers are aligned
    while (count &&
           (!IS_ALIGNED((uintptr_t)dst_casted, bytes_aligned) ||
            !IS_ALIGNED((uintptr_t)buf_casted, bytes_aligned)))
    {
        *dst_casted = *buf_casted;
        dst_casted += 1;
        buf_casted += 1;
        count--;
    }
 
    // Copy aligned chunks
    while (count >= bytes_aligned)
    {
        memcpy(dst_casted, buf_casted, bytes_aligned);
        dst_casted += bytes_aligned;
        buf_casted += bytes_aligned;
        count -= bytes_aligned;
    }
 
    // Copy any remaining bytes
    while (count)
    {
        *dst_casted = *buf_casted;
        dst_casted += 1;
        buf_casted += 1;
        count--;
    }
}
 
void ipc_memcpy_fromio(void *dst, void *buf, size_t count)
{
    printf("\n");
    static int bytes_aligned = IPC_MEMCPY_BYTES_ALIGNED;
    char *dst_casted = (char *)dst;
    char *buf_casted = (char *)buf;
 
    // Copy bytes until both pointers are aligned
    while (count &&
           (!IS_ALIGNED((uintptr_t)dst_casted, bytes_aligned) ||
            !IS_ALIGNED((uintptr_t)buf_casted, bytes_aligned)))
    {
        *dst_casted = *buf_casted;
        dst_casted += 1;
        buf_casted += 1;
        count--;
    }
 
    // Copy aligned chunks
    while (count >= bytes_aligned)
    {
        memcpy(dst_casted, buf_casted, bytes_aligned);
        dst_casted += bytes_aligned;
        buf_casted += bytes_aligned;
        count -= bytes_aligned;
    }
 
    // Copy any remaining bytes
    while (count)
    {
        *dst_casted = *buf_casted;
        dst_casted += 1;
        buf_casted += 1;
        count--;
    }
}
 
/*
* data channel Rx callback: print message, release buffer and signal the
* completion variable.
*/
void data_chan_rx_cb(void *arg, const uint8_t instance, uint8_t chan_id,
                     void *buf, uint32_t data_size)
{
    int err = 0;
    char *endptr;
    char tmp[MAX_SAMPLE_MSG_LEN + 1]; // +1 for null-termination
 
    assert(data_size <= MAX_SAMPLE_MSG_LEN);
 
    /* process the received data */
    ipc_memcpy_fromio(tmp, (char *)buf, data_size);
    // Ensure null-termination to avoid printing garbage or non-UTF8
    if (data_size >= MAX_SAMPLE_MSG_LEN)
        tmp[MAX_SAMPLE_MSG_LEN] = '\0';
    else
        tmp[data_size] = '\0';
 
    sample_info("ch %d << %d bytes: %s\n", chan_id, data_size, tmp);
 
    /* consume received data: get number of message */
    /* Note: without being copied locally */
    app.last_rx_no_msg = strtol((char *)buf + strlen("#"), &endptr, 10);
 
    /* release the buffer */
    err = ipc_shm_release_buf(instance, chan_id, buf);
    if (err)
    {
        sample_err("failed to free buffer for channel %d,"
                   "err code %d\n",
                   chan_id, err);
    }
 
    /* notify send_msg function a reply was received */
    sem_post(&app.sema);
}
 
/*
* control channel Rx callback: print control message
*/
void ctrl_chan_rx_cb(void *arg, const uint8_t instance, uint8_t chan_id,
                     void *mem)
{
    /* temp buffer for string operations that do unaligned SRAM accesses */
    char tmp[CTRL_CHAN_SIZE];
 
    assert(chan_id == CTRL_CHAN_ID);
    assert(strlen(mem) <= CTRL_CHAN_SIZE);
 
    ipc_memcpy_fromio(tmp, (char *)mem, CTRL_CHAN_SIZE);
    sample_info("ch %d << %ld bytes: %s\n", chan_id, strlen(tmp), tmp);
 
    /* notify run_demo() the ctrl reply was received and demo can end */
    sem_post(&app.sema);
}
 
/*
* interrupt signal handler for terminating the sample execution gracefully
*/
void int_handler(int signum)
{
    stop_requested = 1;
    sample_info("SIGINT received, shutting down...\n");
}
 
// Initialize the UDP socket
static int init_udp_socket(void)
{
    udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (udp_socket < 0)
    {
        perror("Failed to create UDP socket");
        return -1;
    }
 
    memset(&udp_addr, 0, sizeof(udp_addr));
    udp_addr.sin_family = AF_INET;
    udp_addr.sin_port = htons(UDP_PORT);
    udp_addr.sin_addr.s_addr = inet_addr(UDP_ADDRESS);
 
    return 0;
}
 
bool sendUdpData(const char *data)
{
    bool result = false;
    // Check if the socket is initialized
    if (udp_socket < 0)
    {
        sample_err("UDP socket not initialized");
        result = false;
    }
 
    // Send the data over UDP
    if (sendto(udp_socket, data, strlen(data), 0, (struct sockaddr *)&udp_addr, sizeof(udp_addr)) < 0)
    {
        sample_err("Failed to send UDP data");
        result = false;
    }
    return result;
}
 
/* Common function to send command */
static void send_command_common(const autoware_auto_control_msgs__msg__AckermannControlCommand *msg, const char *context)
{
    pthread_mutex_lock(&app.lock); // Lock before critical section
    int msg_len = 0;
    uint16_t rpm = (uint16_t)(msg->longitudinal.speed * 400 + 1000);
    if (rpm > 9999)
        rpm = 9999; // Ensure 4-digit max
    sample_info("Received %s command: speed = %f, rpm = %d\n", context, msg->longitudinal.speed, rpm);
    int chan_id = 1;
    char tmp[MAX_SAMPLE_MSG_LEN];
    if (msg->longitudinal.speed >= 9.995)
    {
        msg_len = snprintf(tmp, sizeof(tmp), "%.1f%d", msg->longitudinal.speed, rpm) + 1;
    }
    else
    {
        msg_len = snprintf(tmp, sizeof(tmp), "%.2f%d", msg->longitudinal.speed, rpm) + 1;
    }
    if (msg_len > MAX_SAMPLE_MSG_LEN)
        msg_len = MAX_SAMPLE_MSG_LEN;
 
    char *buf = ipc_shm_acquire_buf(app.instance, chan_id, msg_len);
    if (!buf)
    {
        sample_err("failed to get buffer for channel ID %d and size %d\n", chan_id, msg_len);
        pthread_mutex_unlock(&app.lock);
        return;
    }
 
    ipc_memcpy_toio(buf, tmp, msg_len);
 
    sample_info("ch %d >> %d bytes: speed=%.2f, rpm=%d\n", chan_id, msg_len, msg->longitudinal.speed, rpm);
 
    int err = ipc_shm_tx(app.instance, chan_id, buf, msg_len);
    if (err)
    {
        sample_err("tx failed for channel ID %d, size %d, error code %d\n", chan_id, msg_len, err);
        pthread_mutex_unlock(&app.lock);
        return;
    }
 
    sendUdpData(buf);
 
    sem_wait(&app.sema);
    if (errno == EINTR)
    {
        sample_info("interrupted...\n");
        pthread_mutex_unlock(&app.lock);
        return;
    }
    pthread_mutex_unlock(&app.lock); // Unlock after critical section
}
 
void inj_command_topic_callback(const autoware_auto_control_msgs__msg__AckermannControlCommand *msg)
{
    send_command_common(msg, "injection");
}
 
void longitudinal_command_topic_callback(autoware_auto_control_msgs__msg__AckermannControlCommand *cmd_msg)
{
    send_command_common(cmd_msg, "longitudinal");
}
 
int main(int argc, char *argv[])
{
    int err = 0;
    rcl_ret_t ret;
    struct sigaction sig_action;
    size_t page_size = sysconf(_SC_PAGE_SIZE);
    off_t page_phys_addr;
    uintptr_t local_shm_addr;
    uint32_t shm_size;
    char tmp[IPC_SHM_SIZE] = {0};
 
    app.instance = 0;
    sem_init(&app.sema, 0, 0);
    pthread_mutex_init(&app.lock, NULL); // Initialize mutex
 
    /* init ipc shm driver */
    err = init_ipc_shm();
    if (err)
        return err;
 
    // Initialize the UDP socket
    if (init_udp_socket() < 0)
    {
        sample_err("Error: Unable to initialize UDP socket. Exiting...\n");
        return -1;
    }
 
    /* catch interrupt signals to terminate the execution gracefully */
    sig_action.sa_handler = int_handler;
    sigemptyset(&sig_action.sa_mask);
    sig_action.sa_flags = 0;
    sigaction(SIGINT, &sig_action, NULL);
 
    /* ROS 2 Initialization */
    rcl_allocator_t allocator = rcl_get_default_allocator();
    rclc_support_t support;
 
    sample_info("Initializing RCLC support...\n");
    if (rclc_support_init(&support, argc, (const char *const *)argv, &allocator) != RCL_RET_OK)
    {
        sample_err("Failed to initialize RCLC support\n");
        ipc_shm_free();
        sem_destroy(&app.sema);
        pthread_mutex_destroy(&app.lock); // Destroy mutex
        return -1;
    }
    sample_info("RCLC support initialized.\n");
 
    rcl_node_t node;
    sample_info("Initializing ROS 2 node...\n");
    if (rclc_node_init_default(&node, "autoware_subscriber", "", &support) != RCL_RET_OK)
    {
        sample_err("Failed to initialize ROS 2 node\n");
        rclc_support_fini(&support);
        ipc_shm_free();
        sem_destroy(&app.sema);
        pthread_mutex_destroy(&app.lock); // Destroy mutex
        return -1;
    }
    sample_info("ROS 2 node initialized.\n");
 
    rcl_subscription_t longitudinal_command_subscription;
    rcl_subscription_t inj_longitudinal_command_subscription;
 
    autoware_auto_control_msgs__msg__AckermannControlCommand longitudinal_command_msg = {0};
    autoware_auto_control_msgs__msg__AckermannControlCommand inj_longitudinal_command_msg = {0};
 
    if (rclc_subscription_init_default(
            &longitudinal_command_subscription,
            &node,
            ROSIDL_GET_MSG_TYPE_SUPPORT(autoware_auto_control_msgs, msg, AckermannControlCommand),
            "/control/command/control_cmd") != RCL_RET_OK)
    {
        sample_err("Failed to initialize longitudinal_command_subscription\n");
        ret = rcl_node_fini(&node);
        if (ret != RCL_RET_OK)
        {
            sample_err("Failed to finalize node: %d\n", ret);
        }
        rclc_support_fini(&support);
        ipc_shm_free();
        sem_destroy(&app.sema);
        pthread_mutex_destroy(&app.lock); // Destroy mutex
        return -1;
    }
 
    if (rclc_subscription_init_default(
            &inj_longitudinal_command_subscription,
            &node,
            ROSIDL_GET_MSG_TYPE_SUPPORT(autoware_auto_control_msgs, msg, AckermannControlCommand),
            "/injection/command/control_cmd") != RCL_RET_OK)
    {
        sample_err("Failed to initialize inj_longitudinal_command_subscription\n");
        ret = rcl_node_fini(&node);
        if (ret != RCL_RET_OK)
        {
            sample_err("Failed to finalize node: %d\n", ret);
        }
        rclc_support_fini(&support);
        ipc_shm_free();
        sem_destroy(&app.sema);
        pthread_mutex_destroy(&app.lock); // Destroy mutex
        return -1;
    }
 
    rclc_executor_t executor;
    if (rclc_executor_init(&executor, &support.context, 2, &allocator) != RCL_RET_OK)
    {
        sample_err("Failed to initialize executor\n");
        ret = rcl_subscription_fini(&longitudinal_command_subscription, &node);
        if (ret != RCL_RET_OK)
        {
            sample_err("Failed to finalize longitudinal command subscription: %d\n", ret);
        }
        ret = rcl_subscription_fini(&inj_longitudinal_command_subscription, &node);
        if (ret != RCL_RET_OK)
        {
            sample_err("Failed to finalize inj_longitudinal_command_subscription: %d\n", ret);
        }
        ret = rcl_node_fini(&node);
        if (ret != RCL_RET_OK)
        {
            sample_err("Failed to finalize node: %d\n", ret);
        }
        rclc_support_fini(&support);
        ipc_shm_free();
        sem_destroy(&app.sema);
        pthread_mutex_destroy(&app.lock); // Destroy mutex
        return -1;
    }
 
    rclc_executor_add_subscription(
        &executor, &longitudinal_command_subscription, &longitudinal_command_msg,
        (rclc_callback_t)longitudinal_command_topic_callback, ON_NEW_DATA);
 
    rclc_executor_add_subscription(
        &executor, &inj_longitudinal_command_subscription, &inj_longitudinal_command_msg,
        (rclc_callback_t)inj_command_topic_callback, ON_NEW_DATA);
    // autoware_auto_control_msgs__msg__AckermannControlCommand *command_msg =
    // malloc(sizeof(autoware_auto_control_msgs__msg__AckermannControlCommand));
    // if (command_msg == NULL) {
    // // handle allocation failure
    // }
    // Optionally zero-initialize the allocated memory
    // memset(command_msg, 0, sizeof(autoware_auto_control_msgs__msg__AckermannControlCommand));
    // command_msg->longitudinal.speed = 0;
    while (!stop_requested && rclc_executor_spin_some(&executor, RCL_MS_TO_NS(100)) == RCL_RET_OK)
    {
        // longitudinal_command_topic_callback(command_msg);
        // command_msg->longitudinal.speed += 1.0; // Increment speed for demonstration
    }
 
    // Clean up ROS 2 resources
    rclc_executor_fini(&executor);
    ret = rcl_subscription_fini(&longitudinal_command_subscription, &node);
    if (ret != RCL_RET_OK)
    {
        sample_err("Failed to finalize longitudinal_command subscription: %d\n", ret);
    }
    ret = rcl_subscription_fini(&inj_longitudinal_command_subscription, &node);
    if (ret != RCL_RET_OK)
    {
        sample_err("Failed to finalize inj_longitudinal_command subscription: %d\n", ret);
    }
 
    ret = rcl_node_fini(&node);
    if (ret != RCL_RET_OK)
    {
        sample_err("Failed to finalize node: %d\n", ret);
    }
    rclc_support_fini(&support);
 
    ipc_shm_free();
 
    /* Clear memory to re-init driver */
    local_shm_addr = ipcf_shm_instances_cfg.shm_cfg[0].local_shm_addr;
    shm_size = ipcf_shm_instances_cfg.shm_cfg[0].shm_size;
    page_phys_addr = (local_shm_addr / page_size) * page_size;
    app.local_shm_offset = local_shm_addr - page_phys_addr;
    app.mem_fd = open(IPC_SHM_DEV_MEM_NAME, O_RDWR);
 
    app.local_shm_map = mmap(NULL, app.local_shm_offset + shm_size,
                             PROT_READ | PROT_WRITE, MAP_SHARED,
                             app.mem_fd, page_phys_addr);
 
    app.local_virt_shm = app.local_shm_map + app.local_shm_offset;
 
    memcpy(app.local_virt_shm, tmp, shm_size);
    munmap(app.local_shm_map, app.local_shm_offset + shm_size);
    close(app.mem_fd);
 
    sem_destroy(&app.sema);
    pthread_mutex_destroy(&app.lock); // Destroy mutex
    close(udp_socket);
 
    sample_info("exit\n");
 
    return err;
}
 