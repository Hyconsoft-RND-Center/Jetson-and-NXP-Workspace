/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Copyright 2023-2024 NXP
 */

 #ifndef IPCF_IP_CFG_H
 #define IPCF_IP_CFG_H
 
 #include <stdint.h>
 #include <string.h>
 #include "../ipc-shm.h"
 
 /* callbacks for channels  - must be implemented by application*/
 /* arguments for callbacks - must be implemented by application*/
 
 void ctrl_chan_rx_cb(void *arg, const uint8_t instance, uint8_t chan_id,
			 void *mem);
 void data_chan_rx_cb(void *arg, const uint8_t instance, uint8_t chan_id,
			 void *buf, uint32_t size);
 
 extern const void *rx_cb_arg;
 
 /* ipc shm configuration for all instances */
 extern struct ipc_shm_instances_cfg ipcf_shm_instances_cfg;
 
 #endif /* IPCF_IP_CFG_H */
 