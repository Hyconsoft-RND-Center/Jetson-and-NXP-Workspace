/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Copyright 2023-2024 NXP
 */
#include <linux/ioport.h>
#include <linux/io.h>
#include <linux/interrupt.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/version.h>

#include "ipc-os.h"
#include "ipc-xen.h"
#include "ipc-hw.h"
#include "ipc-shm.h"

#define DRIVER_VERSION	"0.1"

/**
 * struct ipc_os_priv_instance - OS specific private data each instance
 * @shm_size:           local/remote shared memory size
 * @local_phys_shm:     local shared memory physical address
 * @remote_phys_shm:    remote shared memory physical address
 * @local_virt_shm:     local shared memory virtual address
 * @remote_virt_shm:    remote shared memory virtual address
 * @irq_num:            Linux IRQ number
 * @state:              state to indicate whether instance is initialized
 */
struct ipc_os_priv_instance {
	int shm_size;
	uintptr_t local_phys_shm;
	uintptr_t remote_phys_shm;
	uintptr_t local_virt_shm;
	uintptr_t remote_virt_shm;
	int irq_num;
	int state;
};

/**
 * struct ipc_os_priv - OS specific private data
 * @id:             private data per instance
 * @rx_cb:          upper layer rx callback
 * @irq_num_init:   array to save all initialized irq
 */
static struct ipc_os_priv {
	struct ipc_os_priv_instance id[IPC_SHM_MAX_INSTANCES];
	uint32_t (*rx_cb)(const uint8_t instance, int budget);
	int irq_num_init[IPC_SHM_MAX_INSTANCES];
} priv;

static void ipc_shm_softirq(unsigned long arg);
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 10, 0)
static DECLARE_TASKLET(ipc_shm_rx_tasklet, ipc_shm_softirq, 0);
#else
static DECLARE_TASKLET_OLD(ipc_shm_rx_tasklet, ipc_shm_softirq);
#endif

int8_t ipc_hw_init(const uint8_t instance, const struct ipc_shm_cfg *cfg)
{
	(void)instance;
	(void)cfg;

	/* TBD */
	return 0;
}

void ipc_hw_free(const uint8_t instance)
{
	(void)instance;

	/* TBD */
}

int ipc_hw_get_rx_irq(const uint8_t instance)
{
	(void)instance;

	/* TBD */
	return 0;
}


void ipc_hw_irq_enable(const uint8_t instance)
{
	(void)instance;

	/* TBD */
}

void ipc_hw_irq_disable(const uint8_t instance)
{
	(void)instance;

	/* TBD */
}

void ipc_hw_irq_notify(const uint8_t instance)
{
	(void)instance;

	/* TBD */
}

void ipc_hw_irq_clear(const uint8_t instance)
{
	(void)instance;

	/* TBD */
}

/* sotfirq routine for deferred interrupt handling */
static void ipc_shm_softirq(unsigned long arg)
{
	int work = 0;
	unsigned long budget = IPC_SOFTIRQ_BUDGET;
	uint8_t i = 0;

	for (i = 0; i < IPC_SHM_MAX_INSTANCES; i++) {
		if ((priv.id[i].state == IPC_SHM_INSTANCE_DISABLED)
					|| (priv.id[i].irq_num == IPC_IRQ_NONE))
			continue;

		/* Do the budgeted work */
		work = priv.rx_cb(i, budget);

		/* If we used the full budget, schedule again.
		 * We don't know how much work remains until we do the work.
		 * The next tasklet will check for more work
		 */
		if (work >= budget)
			tasklet_schedule(&ipc_shm_rx_tasklet);
		else
			ipc_hw_irq_enable(i);
	}
}

/* driver interrupt service routine */
static irqreturn_t ipc_shm_hardirq(int irq, void *dev)
{
	uint8_t i = 0;

	for (i = 0; i < IPC_SHM_MAX_INSTANCES; i++) {
		if ((priv.id[i].state == IPC_SHM_INSTANCE_DISABLED)
					|| (priv.id[i].irq_num == IPC_IRQ_NONE))
			continue;

		/* disable notifications from remote */
		ipc_hw_irq_disable(i);

		/* clear notification */
		ipc_hw_irq_clear(i);
	}

	tasklet_schedule(&ipc_shm_rx_tasklet);

	return IRQ_HANDLED;
}

/**
 * ipc_shm_os_init() - OS specific initialization code
 * @instance:	 instance id
 * @cfg:         configuration parameters
 * @rx_cb:	rx callback to be called from rx softirq
 *
 * Return: 0 on success, error code otherwise
 */
int8_t ipc_os_init(const uint8_t instance, const struct ipc_shm_cfg *cfg,
		uint32_t (*rx_cb)(const uint8_t, int))
{
	struct resource *res;
	int err;
	int i;

	if (!rx_cb)
		return -EINVAL;

	/* check valid instance */
	if ((instance > IPC_SHM_MAX_INSTANCES) || (instance < 0))
		return -EINVAL;

	/* request and map local physical shared memory */
	res = request_mem_region((phys_addr_t)cfg->local_shm_addr,
				 cfg->shm_size, DRIVER_NAME" local");
	if (!res) {
		shm_err("Unable to reserve local shm region\n");
		return -EADDRINUSE;
	}

	priv.id[instance].local_virt_shm
		= (uintptr_t)ioremap(cfg->local_shm_addr, cfg->shm_size);
	if (!priv.id[instance].local_virt_shm) {
		err = -ENOMEM;
		goto err_release_local_region;
	}

	/* request and map remote physical shared memory */
	res = request_mem_region((phys_addr_t)cfg->remote_shm_addr,
				 cfg->shm_size, DRIVER_NAME" remote");
	if (!res) {
		shm_err("Unable to reserve remote shm region\n");
		err = -EADDRINUSE;
		goto err_unmap_local_shm;
	}

	priv.id[instance].remote_virt_shm
		= (uintptr_t)ioremap(cfg->remote_shm_addr, cfg->shm_size);
	if (!priv.id[instance].remote_virt_shm) {
		err = -ENOMEM;
		goto err_release_remote_region;
	}

	/* save params */
	priv.id[instance].shm_size = cfg->shm_size;
	priv.id[instance].local_phys_shm = cfg->local_shm_addr;
	priv.id[instance].remote_phys_shm = cfg->remote_shm_addr;
	priv.rx_cb = rx_cb;

	if (cfg->inter_core_rx_irq == IPC_IRQ_NONE) {
		priv.id[instance].irq_num = IPC_IRQ_NONE;
	} else {
		/* IRQ TBD */
	}

	/* check duplicate irq number */
	for (i = 0; i < IPC_SHM_MAX_INSTANCES; i++) {
		if (priv.id[instance].irq_num == priv.irq_num_init[i]) {
			priv.id[instance].state = IPC_SHM_INSTANCE_ENABLED;
			return 0;
		}
	}
	priv.irq_num_init[instance] = priv.id[instance].irq_num;

	if (priv.id[instance].irq_num != IPC_IRQ_NONE) {
		/* IRQ TBD */
	}

	priv.id[instance].state = IPC_SHM_INSTANCE_ENABLED;

	return 0;

err_unmap_remote_shm:
	iounmap((void *)cfg->remote_shm_addr);
err_release_remote_region:
	release_mem_region((phys_addr_t)cfg->remote_shm_addr, cfg->shm_size);
err_unmap_local_shm:
	iounmap((void *)cfg->local_shm_addr);
err_release_local_region:
	release_mem_region((phys_addr_t)cfg->local_shm_addr, cfg->shm_size);

	return err;
}

/**
 * ipc_os_free() - free OS specific resources
 */
void ipc_os_free(const uint8_t instance)
{
	priv.id[instance].state = IPC_SHM_INSTANCE_DISABLED;
	/* disable hardirq */
	ipc_hw_irq_disable(instance);

	/* kill softirq task */
	tasklet_kill(&ipc_shm_rx_tasklet);

	/* only free irq if irq number is requested */
	if (priv.irq_num_init[instance] != 0) {
		free_irq(priv.id[instance].irq_num, &priv);
		priv.irq_num_init[instance] = 0;
	}

	iounmap((void *)priv.id[instance].remote_virt_shm);
	release_mem_region((phys_addr_t)priv.id[instance].remote_phys_shm,
		priv.id[instance].shm_size);
	iounmap((void *)priv.id[instance].local_virt_shm);
	release_mem_region((phys_addr_t)priv.id[instance].local_phys_shm,
		priv.id[instance].shm_size);
}

/**
 * ipc_os_get_local_shm() - get local shared mem address
 */
uintptr_t ipc_os_get_local_shm(const uint8_t instance)
{
	return priv.id[instance].local_virt_shm;
}

/**
 * ipc_os_get_remote_shm() - get remote shared mem address
 */
uintptr_t ipc_os_get_remote_shm(const uint8_t instance)
{
	return priv.id[instance].remote_virt_shm;
}

/**
 * ipc_os_map_intc() - I/O memory map interrupt controller register space
 *
 * I/O memory map the inter-core interrupts HW block (MSCM for ARM processors)
 */
void *ipc_os_map_intc(void)
{
	/* TBD */
	return (void *)0;
}

/**
 * ipc_os_map_intc() - I/O memory unmap interrupt controller register space
 */
void ipc_os_unmap_intc(void *addr)
{
	iounmap(addr);
}

/**
 * ipc_os_poll_channels() - invoke rx callback configured at initialization
 *
 * Not implemented for Linux.
 *
 * Return: work done, error code otherwise
 */
int8_t ipc_os_poll_channels(const uint8_t instance)
{
	/* the softirq will handle rx operation if rx interrupt is configured */
	if (priv.id[instance].irq_num == IPC_IRQ_NONE) {
		if (priv.rx_cb != NULL)
			return priv.rx_cb(instance, IPC_SOFTIRQ_BUDGET);
		return -EINVAL;
	}

	return -EOPNOTSUPP;
}

/* module init function */
static int __init shm_mod_init(void)
{
	shm_dbg("driver version %s init\n", DRIVER_VERSION);
	return 0;
}

/* module exit function */
static void __exit shm_mod_exit(void)
{
	shm_dbg("driver version %s exit\n", DRIVER_VERSION);
}

EXPORT_SYMBOL(ipc_shm_init);
EXPORT_SYMBOL(ipc_shm_free);
EXPORT_SYMBOL(ipc_shm_acquire_buf);
EXPORT_SYMBOL(ipc_shm_release_buf);
EXPORT_SYMBOL(ipc_shm_tx);
EXPORT_SYMBOL(ipc_shm_unmanaged_acquire);
EXPORT_SYMBOL(ipc_shm_unmanaged_tx);
EXPORT_SYMBOL(ipc_shm_is_remote_ready);
EXPORT_SYMBOL(ipc_shm_poll_channels);

module_init(shm_mod_init);
module_exit(shm_mod_exit);

MODULE_AUTHOR("NXP");
MODULE_LICENSE("Dual BSD/GPL");
MODULE_ALIAS(DRIVER_NAME);
MODULE_DESCRIPTION("NXP Shared Memory Inter-Processor Communication Driver");
MODULE_VERSION(DRIVER_VERSION);
